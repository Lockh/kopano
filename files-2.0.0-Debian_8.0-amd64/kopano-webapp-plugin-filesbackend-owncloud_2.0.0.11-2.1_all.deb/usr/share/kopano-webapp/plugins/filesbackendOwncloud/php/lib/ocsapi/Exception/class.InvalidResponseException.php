<?php
/**
 * Created by PhpStorm.
 * User: chaas
 * Date: 18.03.15
 * Time: 18:00
 */

namespace OCSAPI\Exception;


class InvalidResponseException extends \Exception {

}