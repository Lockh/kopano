<?php
/**
 * Created by PhpStorm.
 * User: chaas
 * Date: 18.03.15
 * Time: 18:12
 */

namespace OCSAPI\Exception;


class InvalidRequestException extends \Exception{

}