<?php
/**
 * Created by PhpStorm.
 * User: chaas
 * Date: 18.03.15
 * Time: 17:34
 */

namespace OCSAPI\Exception;


class PermissionDeniedException extends \Exception {

}