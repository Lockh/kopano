<?php
namespace Files\Backend;

interface iFeatureVersionInfo
{
	public function getServerVersion();
}