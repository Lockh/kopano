<?php

class Plugindelayeddelivery extends Plugin
{
    /**
     * Called to initialize the plugin and register for hooks.
     */
    function init()
    {
        $this->registerHook('server.core.settings.init.before');
    }

    /**
     * Process the incoming events that where fired by the client.
     *
     * @param String $eventID Identifier of the hook
     * @param Array $data Reference to the data of the triggered hook
     */
    function execute($eventID, &$data)
    {
        switch ($eventID) {
            // Register plugin
            case 'server.core.settings.init.before':
                $this->onBeforeSettingsInit($data);
                break;
        }
    }

    /**
     * Called when the core Settings class is initialized and ready
     * to accept sysadmin default settings. Registers the sysadmin
     * defaults for the DelayDelivery plugin.
     * @param {Array} $data Reference to the data of the triggered hook
     */
    function onBeforeSettingsInit(&$data)
    {
        $data['settingsObj']->addSysAdminDefaults(Array(
            'zarafa' => Array(
                'v1' => Array(
                    'plugins' => Array(
                        'delayeddelivery' => Array(
                            'enable' => PLUGIN_DELAYEDDELIVERY_USER_DEFAULT_ENABLE,
                        )
                    )
                )
            )
        ));
    }
}

?>
