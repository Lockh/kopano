<?php
/** Enable the pimfolder plugin for all users */
define('PLUGIN_PIMFOLDER_USER_DEFAULT_ENABLE', false);
?>
