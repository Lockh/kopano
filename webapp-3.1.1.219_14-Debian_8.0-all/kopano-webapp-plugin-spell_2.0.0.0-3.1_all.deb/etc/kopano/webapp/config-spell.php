<?php

// Configures if this plugin should be enabled by default
define('PLUGIN_SPELLCHECKER_USER_DEFAULT_ENABLE', true);

// Configures the languages that can be used with the spellchecker by default
// It is a comma separated list of languages codes
// E.g.: 'en_US, nl_NL'
// Before adding languages to this configuration setting, the corresponding language pack plugins need to be installed
define('PLUGIN_SPELLCHECKER_SELECTED_LANGUAGES', '');
