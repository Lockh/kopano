<?php
/**
 * spellcheck.php
 *
 * Copyright, Moxiecode Systems AB
 * Released under LGPL License.
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */

require('./includes/Engine.php');
require('./includes/EnchantEngine.php');
require('./includes/PSpellEngine.php');

// Following lines were added by Kopano
require_once('../../../../plugins/spellchecker/php/plugin.spellchecker.php');
$p = new PluginSpellchecker();
$dictDirs = $p->getDictionaryDirectories();

$tinymceSpellCheckerConfig = array(
	"engine" => "enchant", // enchant, pspell

	// Enchant options
	// Edited by Kopano
//	"enchant_dicts_path" => "./dicts",
	"enchant_dicts_path" => "./dicts" . (!empty($dictDirs) ? ":$dictDirs" : ''),

	// PSpell options
	"pspell.mode" => "fast",
	"pspell.spelling" => "",
	"pspell.jargon" => "",
	"pspell.encoding" => ""
);

TinyMCE_Spellchecker_Engine::processRequest($tinymceSpellCheckerConfig);
?>
