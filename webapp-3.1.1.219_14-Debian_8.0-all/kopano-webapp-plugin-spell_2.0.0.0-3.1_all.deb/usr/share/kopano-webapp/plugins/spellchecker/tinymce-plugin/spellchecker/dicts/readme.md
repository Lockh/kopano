Add your dictionary files here for example en_GB.dic and en_GB.aff.
