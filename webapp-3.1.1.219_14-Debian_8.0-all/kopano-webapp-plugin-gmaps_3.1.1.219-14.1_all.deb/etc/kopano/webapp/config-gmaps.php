<?php
//by default gmaps plugin is disabled
define('PLUGIN_GMAPS_USER_DEFAULT_ENABLE', false);
define ('PLUGIN_GMAPS_DEFAULT_ADDRESS','Elektronicaweg 20, 2628 XG Delft, The Netherlands');
define ('PLUGIN_GMAPS_SHOW_ROUTES', false);
?>
