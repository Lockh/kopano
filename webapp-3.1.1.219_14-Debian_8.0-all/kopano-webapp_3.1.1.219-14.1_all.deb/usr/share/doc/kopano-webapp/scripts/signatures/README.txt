Set default signature in WebApp settings script | This wrapper is meant to be an example. We recommend you create your own.

- The example_wrapper script does not work for multi-company.
- For single server. Run: example_wrapper.sh | This will add a default signature for every user found with kopano-admin -l
- Multi-server. Run: multiple_users.sh <server> | This will add a default signature for every user found with kopano-admin -l on <server>
