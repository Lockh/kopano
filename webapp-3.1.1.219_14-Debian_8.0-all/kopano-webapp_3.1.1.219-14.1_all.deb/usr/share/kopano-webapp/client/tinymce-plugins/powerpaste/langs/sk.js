tinymce.addI18n('sk', {
"Paste Formatting Options": "Mo\u017Enosti form\u00E1tovania prilepenia",
"Choose to keep or remove formatting in the pasted content.": "Vyberte, \u010Di chcete ponecha\u0165 alebo odstr\u00E1ni\u0165 form\u00E1tovanie v\u00A0prilepovanom obsahu.",
"Keep Formatting": "Ponecha\u0165 form\u00E1tovanie",
"Remove Formatting": "Odstr\u00E1ni\u0165 form\u00E1tovanie",
"Local Image Import": "Import lok\u00E1lneho obr\u00E1zka",
"Trigger paste again from the keyboard to paste content with images.": "Spustite funkciu prilepenia z kl\u00E1vesnice e\u0161te raz a prilepte obsah s obr\u00E1zkami.",
"Adobe Flash is required to import images from Microsoft Office. Install the <a href=\"http://get.adobe.com/flashplayer/\" target=\"_blank\">Adobe Flash Player</a>.": "Na import obr\u00E1zkov z programu Microsoft Office je potrebn\u00FD doplnok Adobe Flash. Nain\u0161talujte <a href=\"http://get.adobe.com/flashplayer/\" target=\"_blank\">Adobe Flash Player</a>.",
"Press <span class=\"ephox-polish-help-kbd\">ESC</span> to ignore local images and continue editing.": "Stla\u010Den\u00EDm <span class=\"ephox-polish-help-kbd\">ESC</span> ignorujte lok\u00E1lne obr\u00E1zky a\u00A0pokra\u010Dujte v\u00A0\u00FAprav\u00E1ch.",
"Please wait...": "\u010Cakajte pros\u00EDm...",
"Your browser security settings may be preventing images from being imported.": "Nastavenia zabezpe\u010Denia preh\u013Ead\u00E1va\u010Da m\u00F4\u017Eu br\u00E1ni\u0165 v\u00A0importovan\u00ED obr\u00E1zkov.",
"Your browser security settings may be preventing images from being imported. <a href=\"https://support.ephox.com/entries/59328357-Safari-6-1-and-7-Flash-Sandboxing\" style=\"text-decoration: underline\">More information on paste for Safari</a>": "Nastavenia zabezpe\u010Denia preh\u013Ead\u00E1va\u010Da m\u00F4\u017Eu br\u00E1ni\u0165 v\u00A0importovan\u00ED obr\u00E1zkov. <a href=\"https://support.ephox.com/entries/59328357-Safari-6-1-and-7-Flash-Sandboxing\" style=\"text-decoration: underline\">\u010Eal\u0161ie inform\u00E1cie o priliepan\u00ED pre Safari</a>",
"Safari does not support direct paste of images. <a href=\"https://support.ephox.com/entries/88543243-Safari-Direct-paste-of-images-does-not-work\" style=\"text-decoration: underline\">More information on image pasting for Safari</a>": "Preh\u013Ead\u00E1va\u010D Safari nepodporuje priame priliepanie obr\u00E1zkov. <a href=\"https://support.ephox.com/entries/88543243-Safari-Direct-paste-of-images-does-not-work\" style=\"text-decoration: underline\">\u010Eal\u0161ie inform\u00E1cie o priliepan\u00ED obr\u00E1zkov pre preh\u013Ead\u00E1va\u010D Safari</a>",
"The images service was not found: (": "Funkcia obr\u00E1zkov sa nena\u0161la: (",
"Image failed to upload: (": "Obr\u00E1zok sa nepodarilo nahra\u0165: (",
").": ").",
"Local image paste has been disabled. Local images have been removed from pasted content.": "Funkcia vlo\u017Eenia lok\u00E1lneho obr\u00E1zka je vypnut\u00E1. Lok\u00E1lne obr\u00E1zky boli odstr\u00E1nen\u00E9 z vlo\u017Een\u00E9ho obsahu."
});