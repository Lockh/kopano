<?php
// The base URL where the User Manual for WebApp can be found
define('PLUGIN_WEBAPPMANUAL_URL', 'https://documentation.kopano.io/user_manual_webapp/');
define('PLUGIN_WEBAPPMANUAL_USER_DEFAULT_ENABLE', true);
?>
