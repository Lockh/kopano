<?php
/**
 * Set to true to enable the plugin by default
 */
DEFINE('PLUGIN_SPREEDWEBRTC_USER_DEFAULT_ENABLE', false);

/**
 * Set to true to load the plugin on WebApp start up
 */
DEFINE('PLUGIN_SPREEDWEBRTC_AUTO_START', true);

/**
 * The domain name including port and scheme where the spreed server is addressed by the browser. Use empty string if all on one server.
 */
DEFINE('PLUGIN_SPREEDWEBRTC_SPREED_DOMAIN', '');

/** Full path or URL to Spreed WebRTC. */
DEFINE('PLUGIN_SPREEDWEBRTC_SPREED_URL', '/webmeetings/');

/**
 * The domain name including port and scheme where this webapp instance is addressed by the browser. Use empty string when all on one server.
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBAPP_DOMAIN', '');

/** Full path or URL to Spreed WebRTC. */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBAPP_URL', '/webapp/');

/**
 * The secret used to authenticate a Kopano user. Should be the same as the value
 * of the sharedsecret_secret option in the webmeetings.cfg file of the spreed server
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBMEETINGS_SHARED_SECRET', 'the-default-secret-do-not-keep-me');

/**
 * This is the TTL (time to live) in seconds after which the authentication
 * token will expire.
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBMEETINGS_AUTHENTICATION_EXPIRES', 3600);

/**
 * Sets whether only authenticated users can use the spreed app. If set to true
 * only webapp users can access the spreed server
 */
DEFINE('PLUGIN_SPREEDWEBRTC_REQUIRE_AUTHENTICATION', true);

/**
 * Set to true to have console logging on the spreed server
 */
DEFINE('PLUGIN_SPREEDWEBRTC_DEBUG', true);

/**
 * The secret used to authenticate a Kopano user against the kopano-presence service. 
 * Should be the same as the value of the server_secret_key option in the presence.cfg file of kopano-presence
 * 
 */
DEFINE('PLUGIN_SPREEDWEBRTC_PRESENCE_SHARED_SECRET', 'test');

/**
 * This is the TTL (time to live) in seconds after which the presence authentication
 * token will expire.
 */
DEFINE('PLUGIN_SPREEDWEBRTC_PRESENCE_AUTHENTICATION_EXPIRES', 300);

/**
 * Set true to use the Kopano TURN service (requires credetials provided by Kopano)
 */
DEFINE('PLUGIN_SPREEDWEBRTC_TURN_USE_KOPANO_SERVICE', false);

/**
 * This is the URL to the Kopano TURN server authentication server
 */
DEFINE('PLUGIN_SPREEDWEBRTC_TURN_AUTHENTICATION_URL', 'https://turnauth.kopano.com/turnserverauth/');

/**
 * This is your username for the Kopano TURN server authentication server
 * (provided by Kopano)
 */
DEFINE('PLUGIN_SPREEDWEBRTC_TURN_AUTHENTICATION_USER', 'get-your-user-from-kopano');

/**
 * This is your password for the Kopano TURN server authentication server
 * (provided by Kopano)
 */
DEFINE('PLUGIN_SPREEDWEBRTC_TURN_AUTHENTICATION_PASSWORD', 'get-your-password-from-kopano');

/**
 * The secret used to generate Kopano WebAuth tokens
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBAUTH_CODE_TOKEN_SECRET', 'the-default-secret-do-not-keep-me');

/**
 * This is the TTL (time to live) in seconds after which the code
 * token will expire. This should be very short for one time usage
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBAUTH_CODE_TOKEN_EXPIRES', 60);

/**
 * The secret used to generate Kopano WebAuth tokens
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBAUTH_ACCESS_TOKEN_SECRET', 'the-default-secret-do-not-keep-me');

/**
 * This is the TTL (time to live) in seconds after which the access
 * token will expire. This should be as long as the maximum meeting duration with invited guests
 */
DEFINE('PLUGIN_SPREEDWEBRTC_WEBAUTH_ACCESS_TOKEN_EXPIRES', 21600);

/**
 * This is the authentication mechanism for access by external users
 * options are:
 * - simple
 */
DEFINE('PLUGIN_SPREEDWEBRTC_MEETINGS_AUTH_METHOD', 'simple');

?>
