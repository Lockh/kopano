<?php

/**
 * This PHP file is a wrapper around the Angular plugin, to allow it to integrate
 * configuration options from the webapp plugin
 */

include_once('jsconfig.php');

header('Content-Type: application/javascript');

$angular_plugin = "../js/AngularPlugin.js";

$plugin_contents = file_get_contents($angular_plugin);

echo PLUGIN_SPREEDWEBRTC_JS_CONFIG;

echo $plugin_contents . "\n";