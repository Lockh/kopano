<?php

define("MEETINGID_REGEX", "/^[a-z0-9_\-\.]+$/im");
define("MEETINGID_STRIP_REGEX", "/[^A-Za-z0-9_\-\.]/");
define("MEETINGID_ROOMBASE_MAXLEN", 10);
define("DISPLAYNAME_REGEX", "/^[\s,.'\-\pL\]+$/im");

?>
