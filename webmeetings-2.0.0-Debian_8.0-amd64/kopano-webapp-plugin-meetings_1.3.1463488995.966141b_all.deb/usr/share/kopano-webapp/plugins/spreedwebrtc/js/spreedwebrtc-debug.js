Ext.namespace('Zarafa.plugins.spreedwebrtc');

/**
 *
 * @class Zarafa.plugins.spreedwebrtc.SpreedPresence
 * @extends Zarafa.core.Plugin
 *
 */
Zarafa.plugins.spreedwebrtc.SpreedPresence = Ext.extend(Zarafa.core.Plugin, {

	/**
	 * @cfg {String} url
	 * The url used to send the requests to. defaults to presence.
	 */
	url : 'presence',

	/**
	 * @cfg {String} cmd
	 * The GET attribute to send to the server. defaults to 'presence'
	 */
	cmd : 'ping',

	/**
	 * @cfg {Object} headers
	 * The default headers to be applied to the request. defaults to
	 *      'Content-Type' => 'application/json; charset=utf-8;'
	 */
	headers : undefined,

	/**
	 * @cfg {Object} authenticationToken
	 * The authenticationToken to be passed on with the request. 
	 */
	authenticationToken : undefined,

	/**
	 * @cfg {Object} lastAction
	 * The last presence call type sent to the server. 
	 */
	lastAction : undefined,

	/**
	 * @cfg {Number} timeout The polling interval timeout value for the call
	 * to {@link #sendPresence}.
	 */
	interval : 60000,

	/**
	 * @cfg {Number} timeout The polling getdelay timeout value for the call
	 * to {@link #sendGetPresence}.
	 */
	getdelay : 3000,

	/**
	 * @cfg {Number} timeout The initial timeout value for the call
	 * to {@link #sendPresence}. This will be incremented by {@link #getNextTimeout}.
	 */
	timeout : 1000,

	/**
	 * @cfg {Number} maxTimeout The maximum timeout value which can be used
	 * and returned by {@link #getNextTimeout}.
	 */
	maxTimeout : 300000,

	/**
	 * The DelayedTask which will be used to defer the {@link #sendPresence}
	 * function call to periodically update the presence to the server.
	 * @property
	 * @type Ext.util.DelayedTask
	 * @private
	 */
	presenceTask : undefined,

	/**
	 * The DelayedTask which will be used to delay the {@link #sendGetPresence}
	 * function.
	 * @property
	 * @type Ext.util.DelayedTask
	 * @private
	 */
	presenceGetTask : undefined,

	/**
	 * The current timeout value for the {@link #retryTask}.
	 * This is obtained (and incremented) through {@link #getNextTimeout}.
	 * @property
	 * @type Number
	 * @private
	 */
	currentTimeout : undefined,

	/**
	 * True if the Presence has been send to the server, and the PresenceService
	 * is currently awaiting the response from the server.
	 * @property
	 * @type Boolean
	 * @private
	 */
	presencePending : false,

	/**
	 * Reference to the address book store
	 *
	 * @type {object}
	 * @private
	 */
	addressBookStore: null,

	/**
	 * Maintains the list of Kopano emails being monitored
	 *
	 * @type {object}
	 * @private
	 */
	presenceWatchingList : [],

	/**
	 * Maintains the list of Kopano emails being monitored
	 *
	 * @type {object}
	 * @private
	 */
	presenceWatchingListChanged : false,

	/**
	 * Maintains the presence data from the last presence server check
	 *
	 * @type {object}
	 * @private
	 */
	presenceData: undefined,

	/**
	 * Maintains the the known presence user EntryId to Kopano email address mapping
	 *
	 * @type {object}
	 * @private
	 */
	presenceEntryIdEmailAddressMap: {},

	/**
	 * Maintains the known presence user smtp address to Kopano email address mapping
	 *
	 * @type {object}
	 * @private
	 */
	presenceSmtpAddressEmailAddressMap: {},

	/**
	 * Constructor
	 * @protected
	 */
	constructor: function (config) {
		config = config || {};

		Ext.apply(config, {
			// Apply here instead of class prototype, to prevent
			// accidental sharing of object between all instances.
			headers : {
				'Content-Type' : 'application/json; charset=utf-8;'
			}
		});

		Ext.apply(this, config);

		Zarafa.plugins.spreedwebrtc.SpreedPresence.superclass.constructor.call(this, config);

		var spreed_enabled = container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/enable');
		if (! spreed_enabled ) { return; }

		// Instantiate the delayed task for the polling updatePresence function
		this.presenceTask = new Ext.util.DelayedTask(this.updatePresence, this);

		// Instantiate the delayed task for the sendGetPresence retry function
		this.presenceGetTask = new Ext.util.DelayedTask(this.sendGetPresence, this);

		// start the service
		this.start();
	},

	/**
	 * Called after constructor.
	 * Registers insertion points.
	 * @protected
	 */
	initPlugin: function () {
		var spreed_enabled = container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/enable');
		if ( spreed_enabled ) {
			this.registerInsertionPoint('context.addressbook.gridpanel', this.createPresenceColumn, this);
			this.registerInsertionPoint('previewpanel.toolbar.recipientlinks', this.onRecipientLinksShow.createDelegate(this), this);
			this.registerInsertionPoint('context.mail.gridrow', this.createMailGridStatusIcon, this);

			// Listen to creation of a new content panel so we can know if there is a new GAB content panel
			Zarafa.core.data.ContentPanelMgr.on('createcontentpanel', this.onNewContentPanel.createDelegate(this));
		}
		Zarafa.plugins.spreedwebrtc.SpreedPresence.superclass.initPlugin.apply(this, arguments);
	},

	/**
	 * This will add a presence status icon to the mail grid
	 *
	 * @param {String} insertionName
	 * @param {Ext.data.Record} record The {@link Ext.data.Record Record} corresponding to the current row.
	 * @returns {String} A formatted string with icon layout
	 */
	createMailGridStatusIcon: function(insertionName, record) {
		var entryId = record.get('sender_entryid'),
			email_address = record.get('sender_email_address'),
			icon = this.getMailGridStatusIcon(email_address);

		return String.format('<td style="width: 24px;"><div class="grid_compact zarafa_mailgrid_presence_status {0}" style="height: 24px; width: 24px;">&nbsp;</div></td>', icon);
	},

	/**
	 * This will create an extra column in the address book
	 *
	 * @returns {Object} Object with the column definition of the column
	 * @private
	 */
	 createPresenceColumn: function () {
	 	this.refresh();
		return  [{
			dataIndex: 'status_spreed',
			header: _('Spreed'),
			width: 50,
			fixed: true,
			renderer: this.presenceSpreedColumnRenderer
		}]
	},

	/**
	 * This will render the presence (status_spreed) column in the address book
	 *
	 * @param {Object} value The data value for the cell.
	 * @param {Object} p An object with metadata
	 * @param {Ext.data.record} record The {Ext.data.Record} from which the data was extracted.
	 * @private
	 */
	presenceSpreedColumnRenderer: function (value, p, record) {
		p.css += value === 'online' ? 'icon_spreed_status_online' : 'icon_spreed_status_offline';
	},

	/**
	 * This will render the presence (status_xmpp) column in the address book
	 *
	 * @param {Object} value The data value for the cell.
	 * @param {Object} p An object with metadata
	 * @param {Ext.data.record} record The {Ext.data.Record} from which the data was extracted.
	 * @private
	 */
	presenceXmppColumnRenderer: function (value, p, record) {
		if (value === 'online') {
			p.css += 'icon_xmpp_status_available';
		} else if (value === 'available') {
			p.css += 'icon_xmpp_status_available';
		} else if (value === 'away') {
			p.css += 'icon_xmpp_status_away';
		} else if (value === 'busy') {
			p.css += 'icon_xmpp_status_busy';
		} else {
			p.css += 'icon_xmpp_status_unavailable';
		}
	},

	/**
	 * Start the Presence Service and schedule the first run of {@link #presenceTask}.
	 */
	start : function()
	{
		// Schedule the first call
		this.sendPresence();
	},

	/**
	 * Stop the Presence Service and cancel the {@link #presenceTask}.
	 */
	stop : function()
	{
		this.presenceTask.cancel();
	},

	/**
	 * Interrupt the current timeout for {@link #presenceTask} and manually
	 * invoke {@link #sendPresence} causing a new request to be send out right now.
	 */
	update : function()
	{
		this.presenceTask.cancel();
		this.sendPresence();
	},

	/**
	 * Interrupt the current timeout for {@link #presenceTask} and manually
	 * invoke {@link #sendPresence} causing a new request to be send out right now.
	 */
	refresh : function()
	{
		this.presenceGetTask.cancel();
		this.sendGetPresence();
	},

	/**
	 * Check if the watch list changed and refresh if necessary and manually
	 * invoke {@link #refresh} causing a new request to be send out right now.
	 */
	refreshIfPresenceWatchingListChanged : function()
	{
		if (this.presenceWatchingListChanged) {
			this.presenceWatchingListChanged = false;
			this.refresh();
		}
	},

	/**
	 * Obtain the next timeout value for the {@link #presenceTask}. If
	 * {@link #currentTimeout} is initialized this will double the value
	 * (restricted by {@link #maxTimeout}, or otherwise it will take {@link #timeout}.
	 * @return {Number} The timeout for the {@link #presenceTask}
	 * @private
	 */
	getNextTimeout : function()
	{
		this.currentTimeout = this.currentTimeout ? (2 * this.currentTimeout) : this.timeout;
		this.currentTimeout = Math.min(this.maxTimeout, this.currentTimeout);
		return this.currentTimeout;
	},

	/**
	 * Will update the list with online presence users in GAB, links in the mail preview and in the mail grid
	 *
	 * @param {Array} list The list with entry id's of online users
	 * @public
	 */
	updatePresenceUI: function(list) {
		// check if webapp is already initialized, if not then welcome screen is displayed and we return
		if (container.mainPanel === null || typeof container.mainPanel === 'undefined') {
			return;
		}

		// update presence in the address book content panel
		if(Ext.isObject(this.addressBookStore)) {
			this.updateGABContentPanel();
		}

		// update presence in the recipient links from the mail preview panel
		var recipientLinks = container.getMainPanel().findByType('zarafa.recipientlinks');

		// loop through 'to', 'cc' and 'bcc'
		recipientLinks.forEach(function(recipientType) {
			if(recipientType.isVisible()) {
				this.setStatusToRecipients(recipientType);
			}
		}, this);

		// update presence in the mail grid
		var mailGrid = container.getMainPanel().findByType('zarafa.mailgrid')[0];

		if(Ext.isObject(mailGrid)) {
			var records = mailGrid.store.getRange(),
				view = mailGrid.view;

			records.forEach(function(record, index) {
				var entryId = record.get('sender_entryid'),
					email_address = record.get('sender_email_address'),
					presenceCell = view.getRow(index).querySelector('.zarafa_mailgrid_presence_status');
				this.updatePresenceWatchingList(email_address, entryId);
				if (Ext.isObject(presenceCell)) {
					this.setMailGridStatusIcon(presenceCell, email_address, entryId);
				}
			}, this);
		}
	},

	/**
	 * Will set the icon to represent the status of spreed and xmpp
	 *
	 * @param {presenceCell} the presence cell to set the status icon on
	 * @param {String} email_address the email address for which to get the status 
	 * @private
	 */
	setMailGridStatusIcon: function(presenceCell, email_address, entryId) {
		var icon = this.getMailGridStatusIcon(email_address, entryId);

		presenceCell.classList.remove('icon_spreed_status_online_');
		presenceCell.classList.remove('icon_spreed_status_offline');

		// user is online
		if(icon) {
			presenceCell.classList.add(icon);
		}
	},

	/**
	 * Will get the icon to represent the status of spreed and xmpp
	 *
	 * @param {String} email_address the email address to get the status icon 
	 * @private
	 */
	getMailGridStatusIcon: function(email_address, entryId) {
		var online = this.isUserOnline(email_address, entryId, 'spreed');

		if(online) {
			var status_spreed = this.getUserPresence(email_address, entryId, 'spreed');
			if (status_spreed === 'available') {
				return 'icon_spreed_status_online';
			} else {
				return 'icon_spreed_status_offline';
			}
		}
	},


	/**
	 * This will check if a myself is online in Spreed.WebRTC
	 *
	 * @returns {boolean} Whether the user is online in Spreed or not
	 * @private
	 */
	myselfIsOnlineInSpreed: function() {
		var spreedwebrtcPlugin = container.getPluginByName('spreedwebrtc');

		if(Ext.isObject(spreedwebrtcPlugin)) {
			return spreedwebrtcPlugin.isOnlineInSpreed();
		} else {
			return false;
		}
	},

	/**
	 * Will either add or remove an email_address to the watch list
	 *
	 * @param {String} email_address The email address to remove or add
	 * @param {String} remove optionally remove the user from the watch list
	 * @private
	 */
	updatePresenceWatchingList: function(email_address, entryId, smtp_address, remove) {
		if (!email_address || 0 === email_address.length) { return; }
		// skip non-Kopano email addresses
		if (email_address.indexOf('@') > -1) { return; }
		var index = this.presenceWatchingList.indexOf(email_address);

		if(index === -1 && !remove) {
			this.presenceWatchingList.push(email_address);
			this.presenceWatchingListChanged = true;
		}
		else if(index > -1 && remove) {
			this.presenceWatchingList.splice(index, 1);
		}

		if (!entryId || 0 === entryId.length) { return; }
		if (Ext.isObject(this.presenceEntryIdEmailAddressMap)) {
			if (!(entryId in this.presenceEntryIdEmailAddressMap)) {
				this.presenceEntryIdEmailAddressMap[entryId] = email_address;
			}
		}

		if (!smtp_address || 0 === smtp_address.length) { return; }
		if (Ext.isObject(this.presenceSmtpAddressEmailAddressMap)) {
			if (!(smtp_address in this.presenceSmtpAddressEmailAddressMap)) {
				this.presenceSmtpAddressEmailAddressMap[smtp_address] = email_address;
			}
		}
	},

	/**
	 * This will check the user's presence status
	 *
	 * @param {String} email_address The user's email_address
	 * @returns {String} presence status string
	 * @private
	 */
	getUserPresence: function(email_address, entryId, source) {
		if (Ext.isObject(this.presenceData)) {
			if (!email_address || !email_address.length || email_address.indexOf('@') > -1) {
				// this is an empty value or a smtp address, check if we can map the entryId to a Kopano email address
				if (Ext.isObject(this.presenceEntryIdEmailAddressMap)) {
					if (entryId in this.presenceEntryIdEmailAddressMap) {
						email_address = this.presenceEntryIdEmailAddressMap[entryId];
					}
				}
			}

			if (email_address in this.presenceData) {
				if (source in this.presenceData[email_address]) {
					return this.presenceData[email_address][source]['status'];
				}
			}
		}
		return 'unknown';
	},

	/**
	 * This will check the user's presence status
	 *
	 * @param {String} email_address The user's email_address
	 * @returns {String} presence status string
	 * @private
	 */
	getUserEmailAddressFromEntryId: function(email_address, entryId) {
		if (Ext.isObject(this.presenceData)) {
			if (!email_address || !email_address.length || email_address.indexOf('@') > -1) {
				// this is an empty value or a smtp address, check if we can map the entryId to a Kopano email address
				if (Ext.isObject(this.presenceEntryIdEmailAddressMap)) {
					if (entryId in this.presenceEntryIdEmailAddressMap) {
						email_address = this.presenceEntryIdEmailAddressMap[entryId];
					}
				}
			}

		}
		return email_address;
	},

	/**
	 * This will check if the user's presence status is known
	 *
	 * @param {String} email_address The user's email_address
	 * @returns {String} presence status string
	 * @private
	 */
	isUserOnline: function(email_address, entryId, source) {
		if (Ext.isObject(this.presenceData)) {
			if (!email_address || !email_address.length || email_address.indexOf('@') > -1) {
				// this is an empty value or a smtp address, check if we can map the entryId to a Kopano email address
				if (Ext.isObject(this.presenceEntryIdEmailAddressMap)) {
					if (entryId in this.presenceEntryIdEmailAddressMap) {
						email_address = this.presenceEntryIdEmailAddressMap[entryId];
					}
				}
			}

			if (email_address in this.presenceData) {
				if (source in this.presenceData[email_address]) {
					return this.presenceData[email_address][source]['status'] !== 'unavailable';
				}
			}
		}
		return false;
	},

	/**
	 * This adds a show event handler to the recipient links for the insertion point
	 *
	 * @param {String} insertionName insertion point name that is currently populated
	 * @param {Zarafa.common.ui.messagepanel.RecipientLinks} recipientLinks The recipient links
	 * @private
	 */
	onRecipientLinksShow: function(insertionName, recipientLinks) {
		recipientLinks.on('show', this.setStatusToRecipientsHandler, this);
	},

	/**
	 * This will set the presence status of users in the recipient links and refresh status if necessary
	 *
	 * @param {Zarafa.common.ui.messagepanel.RecipientLinks} recipientLinks The recipient links
	 * @private
	 */

	setStatusToRecipientsHandler: function(recipientLinks) {
		this.setStatusToRecipients(recipientLinks);

		this.refresh();
	},

	/**
	 * This will set the presence status of users in the recipient links
	 *
	 * @param {Zarafa.common.ui.messagepanel.RecipientLinks} recipientLinks The recipient links
	 * @private
	 */
	setStatusToRecipients: function(recipientLinks) {
		var recipientLinkElements = recipientLinks.el.query('.zarafa-recipient-link');
		if (Ext.isObject(recipientLinks.store)) {
			var recipients = recipientLinks.store.getRange();

			// set recipients statuses
			recipients.forEach(function(recipient) {
				var name = recipient.get('display_name'),
					email_address = recipient.get('email_address'),
					smtp_address = recipient.get('smtp_address'),
					entryId = recipient.get('entryid');

				this.updatePresenceWatchingList(email_address, entryId, smtp_address);

				recipientLinkElements.forEach(function(element) {
					var text = element.innerHTML;
					if(text.indexOf(name) > -1 && text.indexOf(smtp_address) > -1) {
						this.setLinkStatusIcon(element, entryId, email_address);
					}
				}, this);

			}, this);
		}

		this.setStatustoSentLink();
	},

	/**
	 * This will set the status to the sent link
	 *
	 * @private
	 */
	// FIXME: this function is triggerd when the recipient links are shown but should have its own trigger
	setStatustoSentLink: function() {
		// set sender status
		var sentinfolink = container.getMainPanel().findByType("zarafa.sentinfolinks")[0];

		if(Ext.isDefined(sentinfolink)) {
			var sender = sentinfolink.record,
				entryId = sender.get('sender_entryid'),
				email_address = sender.get('sender_email_address');
				sentLinkElement = sentinfolink.el.query('.zarafa-sentinfo-link')[0];

			this.setLinkStatusIcon(sentLinkElement, entryId, email_address);
		}
	},

	/**
	 * This will set the class status for the element that hold the link in the mail preview panel
	 *
	 * @param {HtmlElement} linkElement The element for which to change the online status
	 * @param {String} entryId The user entry id
	 * @private
	 */
	setLinkStatusIcon: function(linkElement, entryId, email_address) {
		this.updatePresenceWatchingList(email_address, entryId);
		var online = this.isUserOnline(email_address, entryId, 'spreed');
		linkElement.classList.remove('icon_spreed_status_online_link');
		linkElement.classList.remove('icon_spreed_status_offline_link');
		// user is online
		if(online) {
			var status_spreed = this.getUserPresence(email_address, entryId, 'spreed');
			var status_xmpp = this.getUserPresence(email_address, entryId, 'xmpp');
			if (status_spreed === 'available') {
				linkElement.classList.add('icon_spreed_status_online_link');
			} else {
				linkElement.classList.add('icon_spreed_status_offline_link');
			}
		}
	},

	/**
	 * This will update the status of a user in the global address book content panel
	 *
	 * @private
	 */
	updateGABContentPanel: function () {
		var records = this.addressBookStore.getRange();

		for (var i = 0; i < records.length; i++) {
			var entryId = records[i].get('entryid');
			var email_address = records[i].get('email_address');
			var smtp_address = records[i].get('smtp_address');
			this.updatePresenceWatchingList(email_address, entryId);
			var online = this.isUserOnline(email_address, entryId, 'spreed');

			this.updateGABUserStatus(entryId, online ? 'online' : 'offline');
		}
	},

	/**
	 * This will update the presence status of a user in the global address book content panel
	 *
	 * @param {String} entryId The entry id of the user to update
	 * @param {String} newSpreedStatus The user status to update to: online|offline
	 * @private
	 */
	updateGABUserStatus: function (entryId, newSpreedStatus) {
		if (Ext.isObject(this.addressBookStore)) {
			var user = this.addressBookStore.find('entryid', entryId);

			if (user > -1) {
				this.addressBookStore.getAt(user).set('status_spreed', newSpreedStatus);
			}
		}
	},

	/**
	 * Event handler which is called when a new {@link Zarafa.core.ui.ContentPanel contentPanel} is created. It is used
	 * to see if it is an instance of the address book, so we can listen to its load' event.
	 *
	 * @param {Zarafa.core.ui.ContentPanel} contentPanel the new created {@link Zarafa.core.ui.ContentPanel contentPanel}
	 * @private
	 */
	onNewContentPanel: function (contentPanel) {
		var spreedPanel = contentPanel.findByType('zarafa.addressbookcontentpanel')[0];

		if (Ext.isDefined(spreedPanel)) {
			this.addressBookStore = spreedPanel.findByType('zarafa.addressbookgrid')[0].store;

			spreedPanel.mon(this.addressBookStore, 'load', this.updateGABContentPanel.createDelegate(this));
			spreedPanel.on('destroy', this.onDestroyAddressBook.createDelegate(this));
		}
	},

	/**
	 * Event handler which is called when the the address book content panel is destroyed to set the addressbook store
	 * back to null
	 */
	onDestroyAddressBook: function() {
		this.addressBookStore = null;
	},

	/**
	 * Is called to request an authentication token
	 * @private
	 */
	requestAuthentication: function () {
		var responseHandler = new Zarafa.plugins.spreedwebrtc.data.PresenceResponseHandler();

		responseHandler.presence = this;
		container.getRequest().singleRequest('pluginspreedwebrtcmodule', "presenceauth", null, responseHandler);
	},
	/**
	 * prepareHttpRequest prepares xmlHttpRequest object
	 */
	prepareHttpRequest : function(requestData, encoded, url, method, headers, authenticationToken)
	{
		var xmlHttpRequest = new XMLHttpRequest();

		if (!url) {
			//url = this.defaultUrl;
			url = "http://192.168.112.130:1234/"
		}

		xmlHttpRequest.open(method, url, true);
		xmlHttpRequest.requestUrl = url;

		// Apply header from argument, or apply the default headers
		headers = Ext.apply({}, this.requestHeaders, headers || this.defaultHeaders);
		for (var key in headers) {
			xmlHttpRequest.setRequestHeader(key, headers[key]);
		}
		xmlHttpRequest.requestHeaders = headers;

		// Store requestData into the xmlHttpRequest, when the request failed,
		// we can still determine report the failure back to the requestee.
		xmlHttpRequest.requestData = requestData;
		xmlHttpRequest.requestDataEncoded = encoded;
		//xmlHttpRequest.queuedRequests = this.dequeueRequests();

		return xmlHttpRequest;
	},

	/**
	 * sendHttpRequest sends xmlHttpRequest object
	 */
	sendHttpRequest : function(xmlHttpRequest)
	{
		var requestData = xmlHttpRequest.requestData;
		// Register the onready StateChange event handler
		xmlHttpRequest.onreadystatechange = this.stateChange.createDelegate(this, [xmlHttpRequest]);

		// send request
		xmlHttpRequest.send(requestData);
	},

	/**
	 * Send an update Presence request 
	 * @private
	 */
	updatePresence : function()
	{
		this.authenticationToken = undefined;
		this.sendPresence();
	},

	/**
	 * Send an update Presence request 
	 * @private
	 */
	scheduleUpdatePresence : function()
	{
		// get a fresh authenticationToken
		this.authenticationToken = undefined;
		// reset the current timeout
		delete this.currentTimeout;
		// Obtain a new timeout and start polling
		var timeout = this.getNextTimeout();

		this.presenceTask.delay(this.interval);
	},

	/**
	 * Send an update Presence request 
	 * @private
	 */
	scheduleGetPresence : function()
	{
		// reset the current timeout
		delete this.currentTimeout;
		// Obtain a new timeout and start polling
		var timeout = this.getNextTimeout();

		this.presenceGetTask.delay(this.getdelay);
	},

	/**
	 * Send a Presence request to the configured {@link #url}.
	 * {@link #onStateChange} will handle the response as received from the server.
	 * @private
	 */
	sendPresence : function()
	{
		// A Presence request was already sent,
		// we will not send another one simultaneously.
		if (this.presencePending) {
			return;
		}

		if (this.authenticationToken===undefined) {
			this.requestAuthentication();
			return;
		}

		var status;

		if (this.myselfIsOnlineInSpreed()) {
			status = "available";
		} else {
			status = "unavailable";
		}

		var presenceRequest = {
			"AuthenticationToken": this.authenticationToken,
		    "Type": "UserStatus",
		    "UserStatus": [
		        {
		            "user_id": container.getUser().getUserName(),
		            "spreed": {
		                "status": status, 
		                "message": ""
		            }
		        }
		    ]
		};

		var xmlHttpRequest = this.prepareHttpRequest(Ext.encode(presenceRequest), true,this.url, 'PUT', this.headers);

		// Mark that the Presence request is currently pending.
		this.presencePending = true;

		// set the last action for this REST call
		this.lastAction = 'sendPresence';

		// Send the request
		this.sendHttpRequest(xmlHttpRequest)
	},

	/**
	 * Send a Presence request to the configured {@link #url}.
	 * {@link #onStateChange} will handle the response as received from the server.
	 * @private
	 */
	sendGetPresence : function()
	{
		// A Presence request was already sent,
		// we will not send another one simultaneously.
		if (this.presencePending) {
			return;
		}

		if (this.authenticationToken===undefined) {
			this.requestAuthentication();
			return;
		}

		var status;

		// collect the visible email addresses
		this.updatePresenceUI();

		var user_id_data = [];

		// reset the dirty flag
		this.presenceWatchingListChanged = false;

		this.presenceWatchingList.forEach(function(email_address) {
			user_id_data.push({
				"user_id": email_address
			});
		}, this);	 


		var presenceRequest = {
			"AuthenticationToken": this.authenticationToken,
		    "Type": "UserStatus",
		    "UserStatus": user_id_data
		};

		var xmlHttpRequest = this.prepareHttpRequest(Ext.encode(presenceRequest), true, this.url, 'POST', this.headers);

		// Mark that the Presence request is currently pending.
		this.presencePending = true;

		// set the last action for this REST call
		this.lastAction = 'sendGetPresence';

		// Send the request
		this.sendHttpRequest(xmlHttpRequest)
	},

	/**
	 * Called by XMLHttpRequest when a response from the server is coming in. When the entire response has been
	 * completed it calls {@link Zarafa.core.ResponseRouter#receive receive}} which handles the rest of the process.
	 * @param {Object} xmlHttpRequest The raw HTTP request object that is used for communication.
	 * @private
	 */
	stateChange : function(xmlHttpRequest)
	{
		var requestIds = xmlHttpRequest.queuedRequests;
		var responseRouter = container.getResponseRouter();
		var response;

		// The readyState can be 4 values:
		//  0 - Object is created, but not initialized
		//  1 - Request has been opened, but send() has not been called yet
		//  2 - send() has been called, no data available yet
		//  3 - Some data has been received, responseText nor responseBody are available
		//  4 - All data has been received
		//
		// readyState 0 - 3 can be completely ignored by us, as they are only updates
		// about the current progress. Only on readyState 4, should we continue and
		// start checking for the response status.
		if (xmlHttpRequest.readyState != 4) {
			return;
		}

		// Regardless of the state, the Presence request
		// is no longer pending.
		this.presencePending = false;

		// HTTP request must have succeeded
		switch (xmlHttpRequest.status) {
			case 401: /* Unauthorized */
				// Indicate that the user is no longer authenticated with a valid token
				this.failure();
				return;
			case 500: /* Internal Server Error */
				// Indicate that the request failed
				// inside the server and exit the function.
				this.failure();
				return;
			case 200: /* OK */
				break;
			default: /* Connection errors */
				this.failure();
				return;
		}

		// Depending on the response type, convert it into a data Object.
		if (xmlHttpRequest.responseText) {
			// JSON response
			response = Ext.decode(xmlHttpRequest.responseText);
		} else {
			// XML response is not supported
		}

		// PUT request responds without any data.
		if (!Ext.isEmpty(response)) {
			if (this.presenceData === undefined) {
				this.presenceData = {};
			}
			if (this.myselfIsOnlineInSpreed()) {
				response['UserStatus'].forEach(function (userdata) {
					// map data returned
					this.presenceData[userdata['user_id']] = userdata;
				}, this);
			} else {
				// do not display presence info if user is not online in spreed
				this.presenceData = {};
			}
		}

		if (this.lastAction === 'sendPresence') {
			// after updating my status get user status of watched email_addresses
			// schedule the GetPresence poll
			this.scheduleGetPresence();
		} else if (this.lastAction === 'sendGetPresence') {
			// process response
			this.lastAction = undefined;

			// update the UI
			this.updatePresenceUI();

			// schedule the next poll
			this.scheduleUpdatePresence();
		}
//		responseRouter.receive(response);
	},

	/**
	 * Called when the link connection has not been restored and will be
	 * retried later. 
	 * @param {Object} response The response, if any, as received by the server
	 * @private
	 */
	failure : function(response)
	{
		var timeout = this.getNextTimeout();
		this.presenceTask.delay(timeout);
	}

});

Zarafa.onReady(function () {
	container.registerPlugin(new Zarafa.core.PluginMetaData({
		name: 'spreedpresence',
		displayName: _('SpreedPresence Plugin'),
		allowUserVisible : false,
		allowUserDisable : false,
		pluginConstructor: Zarafa.plugins.spreedwebrtc.SpreedPresence
	}));
});

Ext.namespace('Zarafa.plugins.spreedwebrtc');

/**
 *
 * @class Zarafa.plugins.spreedwebrtc.SpreedWebRTC
 * @extends Zarafa.core.Plugin
 *
 */
Zarafa.plugins.spreedwebrtc.SpreedWebRTC = Ext.extend(Zarafa.core.Plugin, {

	/**
	 * Reference to the spreed plugin button
	 *
	 * @type {object}
	 * @private
	 */
	spreedButton: null,

	/**
	 * Reference to the spreed plugin window
	 *
	 * @type {object}
	 * @private
	 */
	spreedWindow: null,

	/**
	 * Reference to the spreed plugin external window
	 *
	 * @type {object}
	 * @private
	 */
	spreedExternalWindow: null,

	/**
	 * The domain origin of the spreed server
	 * (used for postMessage origin check)
	 *
	 * @type {string}
	 * @private
	 */
	spreedDomain: '',

	/**
	 * Maintains a list of persistent notifiers
	 *
	 * @type {object}
	 * @private
	 */
	persistentNotifiers: {},

	/**
	 * Maintains a list of spreed users that are online
	 *
	 * @type {Array}
	 * @private
	 */
	presenceList: [],

	/**
	 * notification element for meeting URL request
	 *
	 * @property
	 * @type Ext.Element
	 * @private
	 */
	notifyEl: undefined,

	/**
	 * Constructor
	 * @protected
	 */

	constructor: function (config) {
		config = config || {};

		Zarafa.plugins.spreedwebrtc.SpreedWebRTC.superclass.constructor.call(this, config);
	},

	/**
	 * Called after constructor.
	 * Registers insertion points.
	 * @protected
	 */
	initPlugin: function () {
		if (!window.location.origin) {
			// Polyfill for IE which does not support location.origin.
			window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
		}

		var spreedDomain = container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/domain/');
		this.spreedDomain = spreedDomain ? spreedDomain : window.location.origin;
		this.registerInsertionPoint('main.toolbar.actions.last', this.createToolBarButton, this);
		this.registerInsertionPoint('context.addressbook.contextmenu.actions', this.createContextItemSpreedChat, this);
		this.registerInsertionPoint('context.addressbook.contextmenu.actions', this.createContextItemSpreedMessage, this);
		this.registerInsertionPoint('context.common.recipientfield.contextmenu.actions', this.createContextItemSpreedChat.createDelegate(this), this);
		this.registerInsertionPoint('context.common.recipientfield.contextmenu.actions', this.createContextItemSpreedMessage.createDelegate(this), this);
		this.registerInsertionPoint('context.mail.contextmenu.options', this.createContextItemSpreedChat, this);
		this.registerInsertionPoint('context.mail.contextmenu.options', this.createContextItemSpreedMessage, this);
		this.registerInsertionPoint('context.calendar.appointmentcontentpanel.toolbar.actions', this.createNewSpreedWebRTCMeetingURLFromAppointmentButton, this);
		this.registerInsertionPoint('context.calendar.appointmentcontentpanel.toolbar.actions', this.createOpenSpreedWebRTCMeetingURLFromAppointmentButton, this);
		this.registerInsertionPoint('context.mail.mailcreatecontentpanel.toolbar.actions', this.createNewSpreedWebRTCMeetingURLFromMailcreateButton, this);

		Zarafa.core.data.SharedComponentType.addProperty('plugin.spreedwebrtc.dialog.spreedwindow');

		// Listen to post message events from Spreed
		window.addEventListener('message', this.onPostMessage.bind(this));

		Zarafa.plugins.spreedwebrtc.SpreedWebRTC.superclass.initPlugin.apply(this, arguments);
	},

	/**
	 * As soon as the spreed button is rendered this will do some initialization. It will also automatically start the
	 * plugin if set in config.php
	 *
	 * @param {Ext.Button} button The spreed button
	 */
	initSpreed: function (button) {
		this.spreedButton = button;

		if (container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/autostart/')) {
			this.createOpenSpreedWebRTC();
			// Workaround to hide close button because panel.tools not mapped in UIFactoryWindowLayer.js
			this.spreedWindow.ownerCt.closable=false;
			this.spreedWindow.ownerCt.tools.close.hide();
			// Note: for the spreed iframe to be constructed the show method of the window in UIFactoryWindowLayer
			// needs so called. Here we hide it again immediately. It's not pretty but it works.
			this.spreedWindow.ownerCt.hide();
		}
	},

	/**
	 * This wil reset some properties when the user closes the spreed window
	 *
	 * @public
	 */
	reset: function() {
		this.spreedWindow = null;
		this.spreedButton.setIconClass('icon_spreed_webrtc');
		this.presenceList = [];
		this.updatePresenceList();
	},

	/**
	 * Creates a button in the main toolbar to create/open the spreed plugin
	 *
	 * @return {Object} Object with the spreed button definition
	 * @private
	 */
	createToolBarButton: function () {
		return  {
			newMenuIndex: 10,
			xtype: 'button',
			scale: 'large',
			listeners: {
				afterrender: function (button) {
					container.getPluginByName('spreedwebrtc').initSpreed(button);
				}
			},
			tooltip: _('Kopano Web Meetings'),
			iconCls: 'icon_spreed_webrtc',
			handler: this.createOpenSpreedWebRTC,
			scope: this
			};
	},

	/**
	 * Will add an extra item to some context menu's for starting a spreed chat
	 *
	 * @returns {Object} insertionName The context menu item
	 * @private
	 */
	createContextItemSpreedChat: function(insertionName) {
		var item = {
			xtype: 'zarafa.conditionalitem',
			text: _('Start video call'),
			overflowText : _('Start video call'),
			iconCls : 'icon_spreed_videocall_context_menu_item',
			singleSelectOnly: true,
			handler: this.startSpreedMeeting,
			beforeShow: this.setContextItemVisibility.createDelegate(item, [insertionName], true),
			scope: this
		};

		return item;
	},

	/**
	 * Will add an extra item to some context menu's for sending a spreed message
	 *
	 * @returns {Object} insertionName The context menu item
	 * @private
	 */
	createContextItemSpreedMessage: function(insertionName) {
		var item = {
			xtype: 'zarafa.conditionalitem',
			text: _('Start chat'),
			overflowText : _('Start chat'),
			iconCls : 'icon_spreed_textchat_context_menu_item',
			singleSelectOnly: true,
			handler: this.sendSpreedMessage,
			beforeShow: this.setContextItemVisibility.createDelegate(item, [insertionName], true),
			scope: this
		};

		return item;
	},

	/**
	 * Will set the visibility of the spreed conditional menu button
	 *
	 * @param {Zarafa.core.ui.menu.ConditionalItem} item The item which is about to be shown.
	 * @param {Zarafa.core.data.MAPIRecord} record The record which is being shown for this menu
	 * @param {String} insertionName The name of the insertion point
	 * @private
	 */
	setContextItemVisibility: function(item, records, insertionName) {
		var record = records[0] || records,
			online = false,
			// for the mail grid context menu get the 'from id' instead of entry id
			entryId = insertionName === "context.mail.contextmenu.options"  ? record.get('sender_entryid') : record.get('entryid'),
			email_address = insertionName === "context.mail.contextmenu.options"  ? record.get('sender_email_address') : record.get('email_address'),
			userId = container.getUser().meta.entryid,
			presencePlugin = container.getPluginByName('spreedpresence');

		if(Ext.isObject(presencePlugin)) {
			online = presencePlugin.isUserOnline(email_address, entryId, 'spreed');
		}
		item.setVisible(online && entryId !== userId);
	},

	/**
	 * Create a button in action toolbar of the Appointment dialog. This will set the
	 * location to the URL of the registered meeting.
	 *
	 * @return {Ext.Button} Button instance
	 * @private
	 */
	createNewSpreedWebRTCMeetingURLFromAppointmentButton : function()
	{
		return {
			xtype : 'button',
			text : _('Add web meeting'),
			iconCls : 'icon_spreed_webmeeting_button',
			handler : this.createNewSpreedWebRTCMeetingURLFromAppointment,
			scope : this,
			plugins : ['zarafa.recordcomponentupdaterplugin'],
			update : function(record, contentReset) {
				this.record = record;
			}
		};
	},

	isNewSpreedWebRTCMeetingURLFromAppointmentButtonVisible : function(record)
	{
		return true;
	},

	createNewSpreedWebRTCMeetingURLFromAppointment : function(btn)
	{
		var appointment = btn.record;
		var editorField = btn.ownerCt.ownerCt.appointmentTab.editorField
		var commonstart = appointment.get('commonstart');
		var commonstart_time = commonstart ? commonstart.getTime() : null;
		var responseHandler = new Zarafa.plugins.spreedwebrtc.data.SpreedWebrtcResponseHandler();

		responseHandler.appointment = appointment;
		responseHandler.editorField = editorField;
		responseHandler.plugin = this;
		this.displayInfoMask();
		container.getRequest().singleRequest('pluginspreedwebrtcmodule', "meetingurl", {'start': commonstart_time}, responseHandler);
	},

	/**
	 * Create a button in action toolbar of the Appointment dialog. This will open the
	 * location of the URL of the registered meeting in an external window.
	 *
	 * @return {Ext.Button} Button instance
	 * @private
	 */
	createOpenSpreedWebRTCMeetingURLFromAppointmentButton : function()
	{
		return {
			xtype : 'button',
			ref : 'openSpreedWebRTCMeetingBtn',
			text : _('Join web meeting'),
			iconCls : 'icon_spreed_webmeeting_button',
			handler : this.openSpreedWebRTCMeetingURLFromAppointment,
			scope : this,
			plugins : ['zarafa.recordcomponentupdaterplugin'],
			update : function(record, contentReset) {
				this.record = record;
				var appointment = record;

				if (appointment.get('location')) {
					this.setDisabled(false);
				} else {
					this.setDisabled(true);
				}
			}
		};
	},

	isOpenSpreedWebRTCMeetingURLFromAppointmentButtonVisible : function(record)
	{
		var appointment = record;

		if (appointment.get('location')) {
			return true;
		} else {
			return false;
		}
	},

	openSpreedWebRTCMeetingURLFromAppointment : function(btn)
	{
		var appointment = btn.record;

		if (!this.spreedExternalWindow || this.spreedExternalWindow.closed) {
			this.spreedExternalWindow = window.open(appointment.get('location'), '_blank', 'location=yes,height=768,width=1024,scrollbars=yes,status=yes');
		} else {
			this.spreedExternalWindow.focus();
			this.spreedExternalWindow.location.href = appointment.get('location');
		}
	},

	/**
	 * this will display to the user that the web meetings URL is being requested.
	 * @protected
	 */
	displayInfoMask : function()
	{
		if (!this.notifyEl) {
			this.notifyEl = container.getNotifier().notify('info.saving', _('Web meetings'), _('requesting web meetings URL, please be patient ...'), {
				persistent : true
			});
		}
	},

	/**
	 * If {@link #displayInfoMask} has been called, this will remove the notification again. 
	 * if the request has been successfull, a new notification will be shown to display that 
	 * the location is set to the URL.
	 * @param {Boolean} success false to disable the display of the URL created message.
	 * @protected
	 */
	hideInfoMask : function(success)
	{
		if (this.notifyEl) {
			container.getNotifier().notify('info.saving', null, null, {
				destroy : true,
				reference : this.notifyEl
			});
			delete this.notifyEl;

			if (success !== false) {
				var notifyEl = container.getNotifier().notify('info.saved', _('The URL for your web meeting is created.'), _('The link is pasted into your mail and the ‘Location’ field. You can open the URL in a new window in case your browser is blocking pop-ups.'), {
					persistent : true
				});
				setTimeout(function() {
					if (notifyEl) {
						container.getNotifier().notify('info.saved', null, null, {
							destroy : true,
							reference : notifyEl
						});
						delete notifyEl;
					}
				}, 10000);
			}
		}
	},

	/**
	 * Create a button in action toolbar of the Mailcreate dialog. This will set the
	 * location to the URL of the registered meeting.
	 *
	 * @return {Ext.Button} Button instance
	 * @private
	 */
	createNewSpreedWebRTCMeetingURLFromMailcreateButton : function()
	{
		return {
			xtype : 'button',
			text : _('Add web meeting'),
			iconCls : 'icon_spreed_webmeeting_button',
			handler : this.createNewSpreedWebRTCMeetingURLFromMailcreate,
			scope : this,
			plugins : ['zarafa.recordcomponentupdaterplugin'],
			update : function(record, contentReset) {
				this.record = record;
			}
		};
	},

	isNewSpreedWebRTCMeetingURLFromMailcreateButtonVisible : function(record)
	{
		return true;
	},

	createNewSpreedWebRTCMeetingURLFromMailcreate : function(btn)
	{
		var mailcreate = btn.record;
		var editorField = btn.ownerCt.ownerCt.editorField
		var start = new Date();
		var start_time = start.getTime();
		var responseHandler = new Zarafa.plugins.spreedwebrtc.data.SpreedWebrtcResponseHandler();

		responseHandler.editorField = editorField;
		responseHandler.plugin = this;
		this.displayInfoMaskMailcreate();
		this.openSpreedWebRTCMeetingURLForMailcreate('');
		container.getRequest().singleRequest('pluginspreedwebrtcmodule', "mailinstantmeetingurl", {'start': start_time}, responseHandler);
	},

	openSpreedWebRTCMeetingURLForMailcreate : function(url)
	{

		if (!this.spreedExternalWindow || this.spreedExternalWindow.closed) {
			this.spreedExternalWindow = window.open(url, '_blank', 'location=yes,height=768,width=1024,scrollbars=yes,status=yes');
		} else {
			this.spreedExternalWindow.focus();
			this.spreedExternalWindow.location.href = url;
		}
	},

	/**
	 * this will display to the user that the web meetings URL is being requested.
	 * @protected
	 */
	displayInfoMaskMailcreate : function()
	{
		if (!this.notifyEl) {
			this.notifyEl = container.getNotifier().notify('info.saving', _('Web meetings'), _('requesting web meetings URL, please be patient ...'), {
				persistent : true
			});
		}
	},

	/**
	 * If {@link #displayInfoMask} has been called, this will remove the notification again. 
	 * if the request has been successfull, a new notification will be shown to display that 
	 * the location is set to the URL.
	 * @param {Boolean} success false to disable the display of the URL created message.
	 * @protected
	 */
	hideInfoMaskMailcreate : function(success)
	{
		if (this.notifyEl) {
			container.getNotifier().notify('info.saving', null, null, {
				destroy : true,
				reference : this.notifyEl
			});
			delete this.notifyEl;

			if (success !== false) {
				var notifyEl = container.getNotifier().notify('info.saved', _('The URL for your web meeting is created.'), _('The link is pasted into your mail. You can open the URL in a new window in case your browser is blocking pop-ups.'), {
					persistent : true
				});
				setTimeout(function() {
					if (notifyEl) {
						container.getNotifier().notify('info.saved', null, null, {
							destroy : true,
							reference : notifyEl
						});
						delete notifyEl;
					}
				}, 10000);
			}
		}
	},

	/**
	 * checks if the user is online in spreed
	 */
	isOnlineInSpreed: function(list) {
		// set this user's status to available only if he is online in spreed
		if(this.spreedWindow != null) {
			// TODO: set online status by postMessage API from Spreed.WebRTC
			return true;
		} else {
			return false;
		}
	},

	/**
	 * Handles the post message data from spreed when it updates the list with online users
	 *
	 * @param {Array} list The list with entry id's
	 * @private
	 */
	refreshPresenceList: function(list) {
		var presencePlugin = container.getPluginByName('spreedpresence');

		if(Ext.isObject(presencePlugin)) {
			this.presenceList = list.slice();
			// add the user to the online list only if he is online
			if(this.spreedWindow != null) {
				this.presenceList.push(container.getUser().meta.entryid);
			}
			presencePlugin.updatePresence(this.presenceList);
		}
	},

	/**
	 * Will either remove an entry id or add it, depending on the status (resp: offline & online)
	 *
	 * @param {String} entryId The entry id to remove or add
	 * @param {String} status The status of the user
	 * @private
	 */
	updatePresenceList: function(entryId, status) {
		var presencePlugin = container.getPluginByName('spreedpresence'),
			index = this.presenceList.indexOf(entryId);

		if(Ext.isObject(presencePlugin)) {
			if(index === -1 && status === 'online') {
				this.presenceList.push(entryId);
			}
			else if(index > -1 && status === 'offline') {
				this.presenceList.splice(index, 1);
			}
			presencePlugin.updatePresence(this.presenceList);
			presencePlugin.update();
		}
	},

	/**
	 * Is called when the plugin on the spreed server requests authorisation
	 * @private
	 */
	requestAuthentication: function () {
		var responseHandler = new Zarafa.plugins.spreedwebrtc.data.SpreedWebrtcResponseHandler();

		responseHandler.spreedWindow = this.spreedWindow;
		container.getRequest().singleRequest('pluginspreedwebrtcmodule', "authenticate", null, responseHandler);
	},

	/**
	 * Notifies the user of spreed events, which are sent through postMessage calls.
	 * These events are about chat messages and calls.
	 *
	 * @param {string} notificationType The type of notification we're dealing with
	 * @param {object} from An object containing info about the 'from' user, like name and id
	 * @private
	 */
	notify: function (notificationType, from) {
		if(Ext.isDefined(from)) {
			var name = from.displayName;
			var notifierId = notificationType + '_' + from.id;
		}

		switch (notificationType) {
			case "chatmessage":
				this.displayNotification(_('New chat message from ') + name, notifierId, true);
				break;
			case "incomingpickuptimeout":
				this.displayNotification(_('Missed call from ') + name, notifierId, true, true);
				this.destroyNotifier('incoming_' + from.id, this.persistentNotifiers['incoming_' + from.id].element);
				break;
			case "incoming":
				this.displayNotification(_('Incoming call from ') + name, notifierId, true);
				break;
			case "busy":
				this.displayNotification(name  + _(' is busy'), notifierId, false);
				break;
			case "reject":
				this.displayNotification(name  + _(' rejected your call'), notifierId, false);
				break;
			case "pickuptimeout":
				this.displayNotification(name  + _(' does not pick up'), notifierId, false);
				break;
			case 'refusedoraccepted':
				this.destroyIncomingNotifiers();
				break;
		}
	},

	/**
	 * This will set the notification messages
	 * *
	 * @param {String} message The message to display
	 * @param {String} notifierId The id by which the notifier is referenced
	 * @param {Boolean} persistent True if the notifier needs to be persistent
	 * @param {Boolean} [displayCount] True if the notifier needs to show a count of the notify event
	 * @private
	 */
	displayNotification: function(message, notifierId, persistent, displayCount) {
		if (persistent) {
			// We have a persistent notification. Applies to missed calls and chat messages
			if (!Ext.isDefined(this.persistentNotifiers[notifierId])) {
				this.persistentNotifiers[notifierId] = {};
				this.persistentNotifiers[notifierId].updateCount = 1;
			}

			if(displayCount) {
				message += ' (' + this.persistentNotifiers[notifierId].updateCount + ')';
			}

			this.persistentNotifiers[notifierId].updateCount += 1;
			this.persistentNotifiers[notifierId].element = container.getNotifier().notify('info.spreednotifier', _('Web Meetings'), message, {
				persistent: true,
				update: this.persistentNotifiers[notifierId].element,
				reference: this.persistentNotifiers[notifierId].element,
				listeners: {
					click: this.destroyNotifier.bind(this, notifierId)
				}
			});
		}
		else {
			// For the other types of notifications we just have disappearing notifications
			container.getNotifier().notify('info.spreednotifier', _('Web Meetings'), message, {
				persistent: false,
				listeners: {
					click: this.destroyNotifier.bind(this, notifierId)
				}
			});
		}
	},

	/**
	 * Event handler for destroying notifiers
	 *
	 * @param {String} notifierId The id of the notifier
	 * @param {Element} element The notifier element
	 * @private
	 */
	destroyNotifier: function (notifierId, element) {
		if (this.persistentNotifiers[notifierId]) {
			this.persistentNotifiers[notifierId] = null;
			delete this.persistentNotifiers[notifierId];
		}

		if (!this.spreedWindow.isVisible()) {
			this.spreedWindow.ownerCt.show();
		}

		container.getNotifier().notify('info.spreednotifier', null, null, {
			reference: element,
			destroy: true
		});
	},

	/**
	 * This function will destroy the notifiers for incoming calls. These notifiers are persistent and will only close
	 * once the call has been accepted or rejected
	 *
	 * @private
	 */
	destroyIncomingNotifiers: function() {
		var notifiers = this.persistentNotifiers;

		for (id in notifiers) {
			if(id.indexOf('incoming') === 0) {
				this.destroyNotifier(id, notifiers[id].element);
			}
		}
	},

	/**
	 * Event handler for opening the Spreed WebRTC iframe window
	 *
	 * @param {Ext.Button} button The button which was clicked
	 * @private
	 */
	createOpenSpreedWebRTC: function (button) {
		if (this.spreedWindow == null) {
			Zarafa.core.data.UIFactory.openLayerComponent(Zarafa.core.data.SharedComponentType['plugin.spreedwebrtc.dialog.spreedwindow'], null, {
				manager: Ext.WindowMgr
			});
		}
		else if(this.spreedWindow.ownerCt.isVisible()) {
			this.spreedWindow.ownerCt.hide();
		}
		else {
			this.spreedWindow.ownerCt.show();
		}
	},

	/**
	 * Event handler for starting a spreed call when clicking on an online user
	 *
	 * @param {Ext.button} button The context menu button
	 * @private
	 */
	startSpreedMeeting: function(button) {
		var records = button.getRecords(),
			record = records[0] || records,
			entryId = record.store instanceof Zarafa.mail.MailStore ? record.get('sender_entryid') : record.get('entryid'),
			presencePlugin = container.getPluginByName('spreedpresence'),
			email_address = presencePlugin.getUserEmailAddressFromEntryId('', entryId),
			activeWindow = Ext.WindowMgr.getActive();

		this.sendPostMessage({'type': 'startCall', userId: email_address});

		// Hide the address book if it is opened
		if(Ext.isObject(activeWindow) && activeWindow.findByType('zarafa.addressbookcontentpanel').length > 0) {
			activeWindow.close();
		}

		// Hide the spreed window if it is opened
		if(!this.spreedWindow.ownerCt.isVisible()) {
			this.spreedWindow.ownerCt.show();
		}
	},

	/**
	 * Event handler for sending a spreed message when clicking on an online user
	 *
	 * @param {Ext.button} button The context menu button
	 * @private
	 */
	sendSpreedMessage: function(button) {
		var records = button.getRecords(),
				record = records[0] || records,
				entryId = record.store instanceof Zarafa.mail.MailStore ? record.get('sender_entryid') : record.get('entryid'),
				presencePlugin = container.getPluginByName('spreedpresence'),
				email_address = presencePlugin.getUserEmailAddressFromEntryId('', entryId),
				activeWindow = Ext.WindowMgr.getActive();

		this.sendPostMessage({'type': 'startChat', userId: email_address});

		// Hide the address book if it is opened
		if(Ext.isObject(activeWindow) && activeWindow.findByType('zarafa.addressbookcontentpanel').length > 0) {
			activeWindow.close();
		}

		// Hide the spreed window if it is opened
		if(!this.spreedWindow.ownerCt.isVisible()) {
			this.spreedWindow.ownerCt.show();
		}
	},

	/**
	 * Sends messages to the spreed app
	 *
	 * @param {Object} data An object with the data to send
	 * @private
	 */
	sendPostMessage: function(data) {
		if(Ext.isObject(this.spreedWindow)) {
			this.spreedWindow.spreedIFrame.getEl().dom.contentWindow.postMessage(data, this.spreedDomain);
		}
	},

	/**
	 * Sends a request to spreed for the buddy list, with postMessage API
	 *
	 * @private
	 */
	requestUsersStatusFromSpreed: function () {
		if(Ext.isObject(this.spreedWindow)) {
			this.sendPostMessage({'type': 'requestBuddyList'});
		}
	},

	/**
	 * Bid for the type of shared component and the given record.
	 * This will bid on plugin.spreedwebrtc.dialog.spreedwindow
	 *
	 * @param {Zarafa.core.data.SharedComponentType} type Type of component a context can bid for.
	 * @param {Ext.data.Record} record Optionally passed record.
	 * @return {Number} The bid for the shared component
	 * @private
	 */
	bidSharedComponent: function (type, record) {
		var bid = -1;

		switch (type) {
			case Zarafa.core.data.SharedComponentType['plugin.spreedwebrtc.dialog.spreedwindow']:
				bid = 1;
				break;
		}
		return bid;
	},

	/**
	 * Will return the reference to the shared component that is requested
	 *
	 * @param {Zarafa.core.data.SharedComponentType} type Type of component a context can bid for.
	 * @param {Ext.data.Record} record Optionally passed record.
	 * @return {Ext.Component} Component
	 * @private
	 */
	getSharedComponent: function (type, record) {
		var component;

		switch (type) {
			case Zarafa.core.data.SharedComponentType['plugin.spreedwebrtc.dialog.spreedwindow']:
				component = Zarafa.plugins.spreedwebrtc.dialogs.SpreedContentPanel;
				break;
		}

		return component;
	},

	/**
	 * Event handler which is called when a post message is received from spreed
	 *
	 * @param {event} e The postMessage event
	 * @private
	 */
	onPostMessage: function (e) {
		var message = e.data;

		// check if the message comes from a valid origin
		if (e.origin != this.spreedDomain) {
			return;
		}

		switch (message.type) {
			case "requestAuthentication":
				this.requestAuthentication();
				this.spreedButton.setIconClass('icon_spreed_webrtc_active');
				this.updatePresenceList();
				break;
			case 'chat':
				this.notify(message.chat, message.from);
				break;
			case 'authentication':
				// do something here message.authentication
				break;
			case 'userStatusChanged':
				this.updatePresenceList(message.userId, message.newStatus);
				break;
			case 'sendBuddyList':
				this.refreshPresenceList(message.list);
				break;
			case 'roomChanged':
				// intended for presence status, will give the new room name -> message.newRoom
		}
	}

});

Zarafa.onReady(function () {
	container.registerPlugin(new Zarafa.core.PluginMetaData({
		name: 'spreedwebrtc',
		displayName: _('Web Meetings Plugin'),
		pluginConstructor: Zarafa.plugins.spreedwebrtc.SpreedWebRTC
	}));
});
Ext.namespace('Zarafa.plugins.spreedwebrtc.data');

/**
 * @class Zarafa.plugins.spreedwebrtc.data.PresenceResponseHandler
 * @extends Zarafa.core.data.AbstractResponseHandler
 *
 * Presence specific response handler.
 */
Zarafa.plugins.spreedwebrtc.data.PresenceResponseHandler = Ext.extend(Zarafa.core.data.AbstractResponseHandler, {

	/**
	 * Stores the Authentication Token in the Presence service
	 * @param {Object} response Object contained the response data.
	 */
	doInfo: function (response) {
		if (response.presenceauth) {
			var presenceauth = response.presenceauth;

			this.presence.authenticationToken = presenceauth.timestamp + ':' + presenceauth.emailaddress + ':' + presenceauth.authtoken.toUpperCase();
			this.presence.sendPresence();
		}
	}
});

Ext.reg('spreedwebrtc.presenceresponsehandler', Zarafa.plugins.spreedwebrtc.data.PresenceResponseHandler);
Ext.namespace('Zarafa.plugins.spreedwebrtc.data');

/**
 * @class Zarafa.plugins.spreedwebrtc.data.SpreedWebrtcResponseHandler
 * @extends Zarafa.core.data.AbstractResponseHandler
 *
 * Spreedwebrtc specific response handler.
 */
Zarafa.plugins.spreedwebrtc.data.SpreedWebrtcResponseHandler = Ext.extend(Zarafa.core.data.AbstractResponseHandler, {

	/**
	 * Opens the window with the url returned from server or show error msg box in case of error.
	 * @param {Object} response Object contained the response data.
	 */
	doInfo: function (response) {
		var spreedDomain = container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/domain');
		if (!spreedDomain) {
			spreedDomain = window.location.origin;
		}

		if (response.authentication) {
			var authentication = response.authentication;

			this.spreedWindow.spreedIFrame.getEl().dom.contentWindow.postMessage({
				type: "authentication",
				authentication: {
					userid: authentication.emailaddress,
					timestamp: authentication.timestamp,
					secret: authentication.secret,
					fullname: container.getUser().getFullName(),
					buddyPicture: authentication.buddyPicture || '',
					turn_ttl: authentication.turn_ttl,
					turn_username: authentication.turn_username,
					turn_password: authentication.turn_password,
					turn_urls: authentication.turn_urls
				}
			},
			spreedDomain);
		} else if (response.meetingurl) {
			var meetingurl = response.meetingurl;
			var x=document.createElement("a");
			x.href=meetingurl.meetingurl;
			this.appointment.set('location', x.href);
			this.editorField.insertAtCursor(
				'\n' +
				meetingurl.headertext + '\n' +
				'\n' +
				x.href + '\n' +
				'\n' +
				meetingurl.footertext  + '\n' +
				'\n' +
				meetingurl.futherinfostext  + '\n' +
				'\n' +
				meetingurl.futherinfosurl  + '\n'
			);
			this.plugin.hideInfoMask(true);
		} else if (response.mailinstantmeetingurl) {
			var mailinstantmeetingurl = response.mailinstantmeetingurl;
			var x=document.createElement("a");
			x.href=mailinstantmeetingurl.meetingurl;
			if (this.editorField.isHtmlEditor()) {
				this.editorField.insertAtCursor(
					'<BR>' +
					mailinstantmeetingurl.headertext_html + '<BR>' +
					'<BR>' +
					x.href + '<BR>' +
					'<BR>' +
					mailinstantmeetingurl.footertext_html  + '<BR>' +
					'<BR>' +
					mailinstantmeetingurl.futherinfostext_html  + '<BR>' +
					'<BR>' +
					mailinstantmeetingurl.futherinfosurl_html  + '<BR>'
				);
			} else {
				this.editorField.insertAtCursor(
					'\n' +
					mailinstantmeetingurl.headertext + '\n' +
					'\n' +
					x.href + '\n' +
					'\n' +
					mailinstantmeetingurl.footertext  + '\n' +
					'\n' +
					mailinstantmeetingurl.futherinfostext  + '\n' +
					'\n' +
					mailinstantmeetingurl.futherinfosurl  + '\n'
				);
			}
			this.plugin.hideInfoMaskMailcreate(true);
			this.plugin.openSpreedWebRTCMeetingURLForMailcreate(x.href);
		}
	}
});

Ext.reg('spreedwebrtc.responsehandler', Zarafa.plugins.spreedwebrtc.data.SpreedWebrtcResponseHandler);
Ext.namespace('Zarafa.plugins.spreedwebrtc.dialogs');

/**
 * @class Zarafa.plugins.spreedwebrtc.dialogs.SpreedContentPanel
 * @extends Zarafa.core.ui.ContentPanel
 *
 * The content panel which contains the spreed application
 * @xtype spreedwebrtc.window
 */
Zarafa.plugins.spreedwebrtc.dialogs.SpreedContentPanel = Ext.extend(Zarafa.core.ui.ContentPanel, {

	/**
	 * @constructor
	 * @param config Configuration structure
	 */
	constructor: function (config) {
		var debug = container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/debug'),
			language = container.getSettingsModel().get('zarafa/v1/main/language').substr(0, 2),
			spreedURL = container.getSettingsModel().get('zarafa/v1/plugins/spreedwebrtc/url/') + '?lang=' + (language || 'en') + (debug ? '&debug' : '');

		config = config || {};
		Ext.applyIf(config, {
			layout: 'fit',
			title: _('Kopano Web Meetings'),
			minimizable: true,
			width: 800,
			height: 500,
			listeners: {
				minimize: function () {
					this.hide();
				},
				close: function () {
					container.getPluginByName('spreedwebrtc').reset();
				}
			},
			items: [
				{
					autoEl: {
						tag: "iframe",
						height: '100%',
						src: spreedURL,
						allowfullscreen: true
					},
					ref: 'spreedIFrame'
				}
			]
		});
		Zarafa.plugins.spreedwebrtc.dialogs.SpreedContentPanel.superclass.constructor.call(this, config);
	},

	/**
	 * initialize component
	 * This will create a reference in the {@link Zarafa.plugins.spreedwebrtc.SpreedWebRTC plugin}, so the
	 * plugin can access its properties
	 * @protected
	 */
	initComponent: function () {
		Zarafa.plugins.spreedwebrtc.dialogs.SpreedContentPanel.superclass.initComponent.call(this);

		container.getPluginByName('spreedwebrtc').spreedWindow = this;
	}
});

Ext.reg('spreedwebrtc.window', Zarafa.plugins.spreedwebrtc.dialogs.SpreedContentPanel);
