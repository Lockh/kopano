// This file is auto generated, do not modify.
"use strict";
define([], function() {
return {"en": "English", "zh-tw": "\u7e41\u9ad4\u4e2d\u6587", "de": "Deutsch", "ko": "\ud55c\uad6d\uc5b4", "zh-cn": "\u4e2d\u6587\uff08\u7b80\u4f53\uff09", "ja": "\u65e5\u672c\u8a9e"};
});
